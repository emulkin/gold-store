import React from 'react';
import {useToDo} from "../../provider";
import Modal from "@mui/material/Modal";

import Box from "@mui/material/Box";
import {Slider} from "@mui/material";
import "bootstrap/dist/css/bootstrap.css"

const Filter = () => {
    const {open3,handleOpen3,handleClose3,date,onSetDate,
        date2,onSetDate2,rangeVal,handleChangeRange,sortedProds} = useToDo()

    return (
        <div className={"filterDiv"}>

            <div className={"filt1"}>

                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M23.8902 0.630824C23.7077 0.229391 23.3427 0 22.9515 0H1.04846C0.657335 0 0.292284 0.258064 0.109758 0.630824C-0.0727673 1.03226 -0.0206171 1.49104 0.214059 1.83513L9.41857 14.5663V22.853C9.41857 23.2832 9.62717 23.6559 9.96614 23.8566C10.1226 23.9427 10.279 24 10.4616 24C10.6702 24 10.8788 23.9427 11.0613 23.7993L13.9556 21.5914C14.3728 21.2473 14.6075 20.7312 14.6075 20.1864V14.5376L23.7859 1.83513C24.0206 1.49104 24.0728 1.03226 23.8902 0.630824ZM13.6688 13.9928C13.6167 14.0789 13.5645 14.1935 13.5645 14.3369V20.1577C13.5645 20.3584 13.4863 20.5305 13.3559 20.6452L10.4616 22.853V14.3369C10.4616 14.1362 10.3833 13.9642 10.253 13.8781L4.36 5.73477H13.8253C14.1121 5.73477 14.3468 5.4767 14.3468 5.16129C14.3468 4.84588 14.1121 4.58781 13.8253 4.58781H3.65597C3.6299 4.58781 3.57775 4.58781 3.55167 4.58781L1.04846 1.14695H22.9515L13.6688 13.9928Z" fill="white"/>
                </svg>
                <span>ф</span>
                <span> и</span>
                <span>л</span>
                <span>ь</span>
                <span>т</span>
                <span>р</span>
            </div>
            <svg width="8" height="14" viewBox="0 0 8 14" fill="none" xmlns="http://www.w3.org/2000/svg" onClick={handleOpen3}>
                <path d="M1 13L7 7L0.999999 1" stroke="white" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
            <Modal
                open={open3}
                onClose={handleClose3}
                aria-labelledby="modal-modal-title"
                aria-describedby="modal-modal-description"
            >
                <Box className={"style3 p-3"}>
                    <div className="d-flex flex-column justify-content-between align-items-center ">

                      <div className="date-box">
                          <input className={"date-input"} type="date" value={date.toLocaleDateString('en-CA')} onChange={onSetDate} />
                          <input className={"date-input"} type="date" value={date2.toLocaleDateString('en-CA')} onChange={onSetDate2} />

                          <button onClick={handleClose3} className={"closeModal2"}>
                              <svg width="8" height="14" viewBox="0 0 8 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                  <path d="M7 13L1 7L7 1" stroke="white" strokeLinecap="round" strokeLinejoin="round"/>
                              </svg>
                          </button>
                      </div>
                        <label className={"w-75 "}>
                           <p  className={"text-left priceP"}> Цена</p>
                        </label>
                        <Box sx={{ width: "80%" ,marginTop:"30px"}}>
                            <Slider
                                getAriaLabel={() => 'Temperature range'}
                                value={rangeVal}
                                onChange={handleChangeRange}
                                valueLabelDisplay="auto"
                                // getAriaValueText={valuetext}
                                valueLabelDisplay="on"
                                min={0}
                                max={Number(sortedProds[sortedProds.length-1].price)}
                                step={1}
                            />
                        </Box>

                        <button className={"modal2_button"}
                                onClick={handleClose3}
                            >
                            сохранить
                        </button>
                    </div>


                </Box>
            </Modal>

        </div>
    );
};

export default Filter;