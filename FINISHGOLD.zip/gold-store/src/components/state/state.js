import Man from "../categories/man";
import Woman from "../categories/woman";
import WomanItems from "../categories/womanItems";
import ManItems from "../categories/manItems";
export const myArray = [
    // {id:Math.random(),path:"/woman/:name/:sub",spouse:"woman",element:<Woman/>, menu:true},
    // {id:Math.random(),path:"/man/:name/:sub",spouse:"man",element:<Man/>, menu:true},
    {id:Math.random(),path:"/woman",spouse:"woman",element:<Woman/>, menu:true},
    {id:Math.random(),path:"/man",spouse:"man",element:<Man/>, menu:true},

]
export const newArray = [
    // {id:Math.random(),path:"/woman/:name/:sub",element:<Items/>,name:"woman", menu:true},
    // {id:Math.random(),path:"/man/:name/:sub",element:<ManItems/>,name:"man", menu:true},
    {id:Math.random(),path:"/woman",element:<WomanItems/>,name:"woman", menu:true},
    {id:Math.random(),path:"/man",element:<ManItems/>,name:"man", menu:true},
]
