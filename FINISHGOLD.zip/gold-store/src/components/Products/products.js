import React, {useEffect, useState} from 'react';
import {useToDo} from "../../provider";
import AddProducts from "./addProducts";
import {useSearchParams} from "react-router-dom";

const Products = () => {
    let filterProduct = []
    const {products, search, rangeVal, sub} = useToDo()
    const [searchParams,setSearchParams] = useSearchParams()


    const [array, setArray] = useState([])

    useEffect(() => {
        filterProduct = products.filter((product) => product.price >= rangeVal[0] && product.price <= rangeVal[1])
        setArray(filterProduct)

        filterProduct = filterProduct.filter((product) => {
                if (
                    product.name
                        .toLowerCase()
                        .includes(search.toLowerCase())
                ) {
                    return product;
                }
            }
        )
        setArray(filterProduct)


    }, [products, rangeVal, search])

    return (
        <div className={"productsBox"}>
                {
                    array.map((product) => {
                        if (searchParams.get('subCategory') === product.category) {
                            return (
                                    <div className={"product"} key={product.id}
                                         // onClick={() => {
                                         //     setSearchParams({
                                         //         gender: searchParams.get('gender'),
                                         //         category: searchParams.get('category'),
                                         //         subCategory: searchParams.get('subCategory'),
                                         //         product: product.name
                                         //     })
                                         // }
                                         // }
                                    >
                                        <img src={product.img} width={"170px"} height={"110px"} alt={product.name}/>
                                        <p>{product.name} <span>{product.price}$</span></p>
                                    </div>
                            )
                        }
                    })
                }

            { searchParams.get('category') && searchParams.get('subCategory') ? <AddProducts/> : null}
        </div>
    );
}
    ;

    export default Products;