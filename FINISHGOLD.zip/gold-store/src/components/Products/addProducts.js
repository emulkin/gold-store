import React, {useEffect, useState} from 'react';
import Modal from "@mui/material/Modal";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import {useToDo} from "../../provider";
import button from "bootstrap/js/src/button";
import {useSearchParams} from "react-router-dom";

const AddProducts = () => {
    const {open4, style4, handleOpen4, handleClose4, images2, setImages2,imgURLs2,
        setImgURLs2, onImageChange2,val1,setVal1,val2,setVal2,sub,products,setProducts,gender
        ,setRangeVal,rangeVal,sortedProds,handleChangeRange
    } = useToDo()

    const [searchParams,setSearchParams] = useSearchParams()

    useEffect(() => {
        if (images2.length < 1) return;
        const newUrls2 = []
        images2.forEach(image1 => newUrls2.push(URL.createObjectURL(image1)));
        setImgURLs2(newUrls2)
    }, [images2])


    const newVal = sortedProds[sortedProds.length-1].price


    return (
        <div>
            <button className="add-categories" onClick={handleOpen4}>
                <svg xmlns="http://www.w3.org/2000/svg" fill="rgb(132 127 127)"
                     className="bi bi-plus" viewBox="0 0 16 16">
                    <path
                        d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4z"/>
                </svg>
            </button>
            <Modal
                open={open4}
                onClose={handleClose4}
                aria-labelledby="modal-modal-title"
                aria-describedby="modal-modal-description"
            >
                <Box sx={style4}>
                    <div className="d-flex justify-content-between align-content-center">
                        <Typography className="modalTitle mb-2" variant="h6" component="h2">
                            добавить изделия {sub}
                        </Typography>
                        <button onClick={handleClose4} className={"closeModal"}>
                            <svg xmlns="http://www.w3.org/2000/svg" width="16px" height="16px" fill="#4F4F4F"
                                 className="bi bi-x" viewBox="0 0 16 16">
                                <path
                                    d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"/>
                            </svg>
                        </button>
                    </div>
                    <div className="d-flex flex-column justify-content-between flex-md-wrap align-content-start">


                        <input type="text" value={val1} onChange={(e) => setVal1(e.target.value)}
                               placeholder={"артикул"} style={{border: "none", paddingBottom: "10px"}}/>
                        <input type="number"  value={val2} onChange={(e) => setVal2(e.target.value)}
                               placeholder={"цена"} style={{border: "none", paddingBottom: "10px"}}/>
                    </div>
                    <div className={"dropzone1"}>
                        {!imgURLs2.length ? <input
                                className={"dropzoneInput"}
                                type="file" multiple accept="image/*"
                                onChange={onImageChange2}
                                onClick={(event) => {

                                }}
                            /> :
                            <>
                                <input
                                    className={"dropzoneInputSmall"}
                                    type="file" multiple accept="image/2/*"
                                    onChange={onImageChange2}
                                    onClick={(event) => {

                                    }}
                                />
                                {imgURLs2.map(imgSrc2 =>
                                    <img key={Math.random()} width={"100%"} height={"100%"} src={imgSrc2}
                                                            alt="img2"/>)}
                            </>
                        }

                        {/*[0,sortedProds[sortedProds.length-1].price]*/}

                        <button className={"modal2_button"} onClick={() => {
                            setRangeVal([20,newVal])
                            if (val1.trim() && val2.trim() && imgURLs2.length ) {

                                handleChangeRange(0,[0,Math.max(sortedProds[sortedProds.length-1].price, Number(val2))])

                                setProducts([...products, {
                                    name: val1,
                                    id: Math.random(),
                                    img: imgURLs2,
                                    price: Number(val2),
                                    category: searchParams.get('subCategory'),
                                    gender:gender,
                                }])
                                setImages2([])
                                setImgURLs2([])
                                setVal1("")
                                setVal2("")
                                handleClose4()
                                localStorage.setItem("products", JSON.stringify([...products, {
                                    name: val1,
                                    id: Math.random(),
                                    img: imgURLs2,
                                    price: Number(val2),
                                    category: searchParams.get('subCategory'),
                                    gender:gender,
                                }]));
                            }
                        }
                        }>Добавить
                        </button>

                    </div>
                </Box>
            </Modal>
        </div>
    );
};

export default AddProducts;