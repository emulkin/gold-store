import React, {useEffect, useState} from 'react';
import {useToDo} from "../../provider";
import ButtonAdd from "../dropzone/dropzone1";
import {useLocation, useSearchParams} from "react-router-dom";
import {myArray} from "../state/state";
import ManItems from "./manItems";
import WomanItems from "./womanItems";

const Category = () => {
    const {item} = useToDo()
    const [searchParams, setSearchParams] = useSearchParams()


    return (
        <div className="categories">
            <div className="spouse">
                {
                    myArray.map(({id, element, spouse}) => {

                        return (
                            <div key={id} onClick={() => setSearchParams({
                                gender: spouse
                            })}>
                                {element}
                            </div>
                        )
                    })
                }
            </div>

            {/*{searchParams.get('gender') === 'man' ? <ManItems/> : <WomanItems/>}*/}

            {searchParams.get('gender') === 'man' && (<ManItems/>)}
            {searchParams.get('gender') === 'woman' && (<WomanItems/>)}

            <ButtonAdd/>
        </div>
    );
};

export default Category;

