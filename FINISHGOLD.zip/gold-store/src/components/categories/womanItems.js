import React, {useState} from 'react';
import {useToDo} from "../../provider";
import "bootstrap/dist/css/bootstrap.css"
import {useSearchParams} from "react-router-dom";

const WomanItems = () => {
    const {item: category, gender, setProd,choosen,setChoosen} = useToDo()
    const [] = useState()

    const [searchParams, setSearchParams] = useSearchParams()

    return (
        <div className="d-flex">
            {

                category.map(({id, name, img, spouse}) => {
                    return (
                        spouse === 'woman' ? <div
                            key={id}
                            className={searchParams.get("category") === name ? "choosen" : "bijou"}
                            onClick={() => {
                            setProd(name)
                            setChoosen(id)
                            setSearchParams({
                                gender: searchParams.get('gender'),
                                category: name
                            })
                        }}>
                            <img alt={"img"} src={img}/>
                            <span>{name}</span>
                        </div> : null
                    )
                })
            }
        </div>
    );
};

export default WomanItems;