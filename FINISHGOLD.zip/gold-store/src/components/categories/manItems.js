import React, {useState} from 'react';
import {useToDo} from "../../provider";
import {useSearchParams} from "react-router-dom";

const ManItems = () => {
    const {item: category, gender, setProd,choosen1,setChoosen1} = useToDo()
    const [searchParams, setSearchParams] = useSearchParams()

    return (
        <div className="d-flex">
            {
                category.map(({id, name, img, spouse}) => {
                    return (
                        spouse === 'man' ? <div
                            key={id}
                            // className={choosen1 === id ? "choosen" : "bijou"}
                            className={searchParams.get("category") === name ? "choosen" : "bijou"}
                            onClick={() => {
                            setProd(name)
                            setChoosen1(id)
                            setSearchParams({
                                gender: searchParams.get('gender'),
                                category: name
                            })
                            // set('category', name)
                        }}>
                            <img alt={"img"} src={img}/>
                            <span>{name}</span>
                        </div> : null
                    )
                })
            }
        </div>
    );

};

export default ManItems;