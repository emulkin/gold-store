import React from 'react';
import SubCategory from "../subCategories/subCategory";

const Nav = () => {
    return (
        <div>
            <SubCategory/>

        </div>
    );
};

export default Nav;