import React, { useEffect} from 'react';
import {useToDo} from "../provider";
import {useSearchParams} from "react-router-dom";

const ExmplDropzone = () => {
    const {
        images,
        setImages,
        imgURLs,
        setImgURLs,
        onImageChange,
        setItem,
        item,
        value,
        setValue,
        handleClose,
        gender2,
    } = useToDo()

    useEffect(() => {
        if (images.length < 1) return;
        const newUrls = []
        images.forEach(image => newUrls.push(URL.createObjectURL(image)));
        setImgURLs(newUrls)
    }, [images])

    const [searchParams, setSearchParams] = useSearchParams()


    return (
        <div className={"dropzone1"}>
            {!imgURLs.length ? <input
                    className={"dropzoneInput"}
                    type="file" multiple accept="image/*"
                    onChange={onImageChange}
                    onClick={(event) => {

                    }}
                /> :
                <>
                    <input
                        className={"dropzoneInputSmall"}
                        type="file" multiple accept="image/*"
                        onChange={onImageChange}
                        onClick={(event) => {

                        }}
                    />
                    {imgURLs.map(imgSrc => <img key={Math.random()} width={"100%"} height={"100%"} src={imgSrc}
                                                alt="img"/>)}
                </>
            }


            <button className={"hrBox button"} onClick={() => {

                if (value.trim() && imgURLs.length ) {
                    setItem([...item, {
                        id: Math.random(),
                        img: imgURLs,
                        name: value,
                        spouse: gender2,
                    }])
                    setSearchParams({
                        gender: gender2,
                    })
                    setValue("")
                    setImages([])
                    setImgURLs([])
                    handleClose()
                    localStorage.setItem("item", JSON.stringify([...item, {
                        id: Math.random(),
                        img: imgURLs,
                        name: value,
                        spouse: gender2,
                    }]));
                }
            if (!value){
                return alert("check cat")
            }
            }

            }>
                Добавить
            </button>

        </div>
    );
};

export default ExmplDropzone;

