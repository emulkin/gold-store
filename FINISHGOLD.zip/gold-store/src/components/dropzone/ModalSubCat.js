import React from 'react';
import {useToDo} from "../../provider";
import Modal from "@mui/material/Modal";
import Box from "@mui/material/Box";
import {useSearchParams} from "react-router-dom";

const ModalSubCat = () => {
    const {open2,setOpen2,handleOpen2,handleClose2,
        style2,subval,setSubval,cat,setCat,prod,gender}=useToDo()

    const  [searchParams] = useSearchParams()
    return (
        <div>
            <button className={"add-subCategories"} onClick={handleOpen2}>
                <svg xmlns="http://www.w3.org/2000/svg" fill="rgb(132 127 127)"
                     className="bi bi-plus" viewBox="0 0 16 16">
                    <path
                        d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4z"/>
                </svg>
            </button>
             <Modal
                open={open2}
                onClose={handleClose2}
                aria-labelledby="modal-modal-title"
                aria-describedby="modal-modal-description"
            >
                <Box sx={style2}>
                    <div className="d-flex justify-content-between align-content-center">
                        <strong>
                            {prod} : Добавить Подкатегория
                        </strong>
                        <button onClick={handleClose2} className={"closeModal"}>
                            <svg xmlns="http://www.w3.org/2000/svg" width="16px" height="16px" fill="#4F4F4F"
                                 className="bi bi-x" viewBox="0 0 16 16">
                                <path
                                    d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"/>
                            </svg>
                        </button>
                    </div>
                    <input type="text"
                           className={"modal2_input"}
                           placeholder={"Подкатегория"}
                           value={subval}
                           onChange={(e) => setSubval(e.target.value)}
                    />
                    <button className={"modal2_button"} onClick={() => {
                        if (subval.trim() && prod !== null) {
                            setCat([...cat, {
                                id: Math.random(),
                                id2: Math.random(),
                                name: subval,
                                cat: searchParams.get('category'),
                                spouse: gender
                            }])
                            setSubval("")
                            setOpen2(false)
                            localStorage.setItem("cat", JSON.stringify([...cat, {
                                id2: Math.random(),
                                id: Math.random(),
                                name: subval,
                                cat: searchParams.get('category'),
                                spouse: gender
                            }]));
                        }
                        if (!subval) {
                            return alert("check name")
                        }
                    }
                    }>
                        Добавить
                    </button>
                </Box>
            </Modal>
        </div>
    );
};

export default ModalSubCat;