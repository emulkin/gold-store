//
import React, {useState} from 'react';
import Modal from "@mui/material/Modal";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import {useToDo} from "../../provider";
import ExmplDropzone from "../exmplDropzone";
import {useFormik} from "formik";
import {alpha, InputBase, styled, TextField} from "@mui/material";
import * as PropTypes from "prop-types";


function ValidationTextField(props) {
    return null;
}

ValidationTextField.propTypes = {
    defaultValue: PropTypes.string,
    variant: PropTypes.string,
    label: PropTypes.string,
    id: PropTypes.string,
    required: PropTypes.bool
};
const ButtonAdd = () => {
    const {handleOpen, open, handleClose, style1, value, setValue, setGender2, gender2} = useToDo()

    const [color, setColor] = useState("#939393")
    const [color2, setColor2] = useState("#11338a")

    return (

        <div>
            <button className="add-categories" onClick={handleOpen}>
                <svg xmlns="http://www.w3.org/2000/svg" fill="rgb(132 127 127)"
                     className="bi bi-plus" viewBox="0 0 16 16">
                    <path
                        d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4z"/>
                </svg>
            </button>
            <Modal
                open={open}
                onClose={handleClose}
                aria-labelledby="modal-modal-title"
                aria-describedby="modal-modal-description"
            >
                <Box sx={style1}>
                    <div className="d-flex justify-content-between align-content-center">
                        <Typography className="modalTitle" variant="h6" component="h2">
                            добавить категория
                        </Typography>
                        <button onClick={handleClose} className={"closeModal"}>
                            <svg xmlns="http://www.w3.org/2000/svg" width="16px" height="16px" fill="#4F4F4F"
                                 className="bi bi-x" viewBox="0 0 16 16">
                                <path
                                    d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"/>
                            </svg>
                        </button>
                    </div>
                    <div className="d-flex justify-content-between flex-md-wrap align-content-center">
                        <button className="man2" onClick={() => {
                            setColor("#11338a")
                            setColor2("#939393")
                            setGender2("man")
                        }}>
                            <svg width="19" height="18" viewBox="0 0 19 18" fill="none"
                                 xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M18.989 17.5343L18.514 15.7343C18.2887 14.861 17.6054 14.1588 16.705 13.875L13.2217 12.7755C12.3722 12.4403 11.9835 11.1443 11.8996 10.6522C12.5469 10.1423 12.9633 9.41685 13.0634 8.62499C13.0491 8.48974 13.0828 8.35383 13.1591 8.23873C13.2826 8.20944 13.3836 8.1257 13.4307 8.01373C13.6586 7.49088 13.8016 6.93837 13.855 6.37499C13.8551 6.34437 13.8512 6.31389 13.8431 6.28425C13.7864 6.06533 13.6506 5.87215 13.4592 5.73824V3.74998C13.4592 2.54173 13.0697 2.04599 12.6596 1.75873C12.5813 1.17675 11.9234 0 9.50089 0C7.35163 0.0819844 5.62909 1.71387 5.54255 3.75001V5.73827C5.35114 5.87218 5.21528 6.06537 5.15858 6.28429C5.15056 6.31392 5.14659 6.34444 5.1467 6.37502C5.19999 6.93868 5.34305 7.49145 5.57105 8.01453C5.60534 8.12053 5.69525 8.20206 5.80855 8.2298C5.85289 8.25078 5.93602 8.35956 5.93602 8.62506C6.03662 9.41917 6.45551 10.1463 7.10611 10.6561C7.02299 11.1473 6.63664 12.4426 5.81096 12.7696L2.29674 13.875C1.3971 14.1588 0.714283 14.8603 0.488584 15.7328L0.0135835 17.5328C-0.040188 17.7336 0.0879879 17.9376 0.299882 17.9885C0.331537 17.9962 0.364082 18 0.396738 18.0001H18.6051C18.8237 18 19.0009 17.8321 19.0008 17.625C19.0008 17.5943 18.9968 17.5639 18.989 17.5343Z"
                                    fill={color}/>
                            </svg>
                            мужской
                        </button>
                        <button className="woman2" onClick={() => {
                            setColor2("#11338a")
                            setColor("#939393")
                            setGender2("woman")
                        }
                        }>
                            <svg width="19" height="18" viewBox="0 0 18 18" fill="none"
                                 xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M3.19275 13.5375L6.06599 12.8196L6.23176 12.1564C5.16951 12.0125 4.13926 11.6902 3.18453 11.2032C3.07811 11.1394 3.01019 11.0272 3.00301 10.9034C2.99549 10.7796 3.04896 10.6598 3.14628 10.5827C3.15978 10.5737 4.50003 9.46762 4.50003 5.63532C4.50003 2.40326 5.25677 0.764386 6.75003 0.764386H6.97503C7.49309 0.208152 8.24431 -0.0698417 9.00002 0.0150247C10.4093 0.0150247 13.5 1.4306 13.5 5.63532C13.5 9.46762 14.8403 10.5737 14.85 10.5812C15.0158 10.7051 15.0497 10.9399 14.9257 11.1057C14.8966 11.1445 14.8602 11.1774 14.8185 11.2024C13.8646 11.694 12.833 12.0175 11.769 12.1586L11.9348 12.8203L14.8072 13.5382C16.6853 14.0051 18.0027 15.6915 18 17.6253C18 17.8322 17.8321 18 17.625 18H0.374987C0.167881 18 -2.47955e-05 17.8322 -2.47955e-05 17.6253C-0.00308418 15.6913 1.31436 14.0044 3.19275 13.5375Z"
                                    fill={color2}/>
                            </svg>
                            женский
                        </button>

                    </div>
                    <div className="hrBox">
                        {/*<input type="text"*/}
                        {/*                 value={value}*/}
                        {/*                 onChange={(e) => {*/}
                        {/*                     setValue(e.target.value)*/}
                        {/*                 }}*/}
                        {/*                 placeholder={"категория"}*/}
                        {/*                 style={{border: "1px solid red", margin:"3px",width: "90%", paddingBottom: "10px"}}*/}
                        {/*    />*/}
                     <TextField id="standard-basic" value={value} onChange={(e)=>setValue(e.target.value)} label="Category Name" variant="standard" style={{marginBottom:"10px"}} />
                        <ExmplDropzone/>


                    </div>


                </Box>
            </Modal>
        </div>
    );
};

export default ButtonAdd;

//

