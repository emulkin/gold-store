import React, {useState} from 'react';
import {useToDo} from "../../provider";
import ModalSubCat from "../dropzone/ModalSubCat";
import {useSearchParams} from "react-router-dom";


const SubCategory = () => {
        const {cat, setSub, prod} = useToDo()
        const [searchParams, setSearchParams] = useSearchParams()
        const [liner, setLiner] = useState(null)

        return (
            <div className={"subCategories"}>

                <ul className={"ulDiv"}>

                    {
                        cat.map(({id, id2, name, cat,}) => {

                            if (
                                searchParams.get('gender') === 'man' &&
                                searchParams.get('category') === cat
                            ) {
                                return (
                                    <li key={id}
                                        // className={liner === id ? "liner" : "liDiv"}
                                        className={searchParams.get("subCategory") === name ? "liner" : "liDiv"}
                                        onClick={(e) => {
                                            setSub(true)
                                            setLiner(id)
                                        }}>
                                        <div
                                            key={id2}
                                            onClick={(e) => {
                                                setSearchParams({
                                                    gender: searchParams.get('gender'),
                                                    category: cat,
                                                    subCategory: name
                                                })
                                            }}
                                        > {name}</div>
                                    </li>
                                )
                            }
                            if (searchParams.get('gender') === 'woman' &&
                                searchParams.get('category') === cat
                            ) {
                                return (
                                    <>
                                        <li key={id}
                                            // className={liner === id ? "liner" : "liDiv"}
                                            className={searchParams.get("subCategory") === name ? "liner" : "liDiv"}
                                            onClick={() => {
                                                setSub(true)
                                                setLiner(id)
                                            }}>
                                            <div
                                                key={id2}
                                                onClick={() => {
                                                    setSearchParams({
                                                        gender: searchParams.get('gender'),
                                                        category: cat,
                                                        subCategory: name
                                                    })
                                                }
                                                }> {name}</div>
                                        </li>
                                    </>
                                )
                            }
                        })

                    }


                </ul>
                {
                    searchParams.get('gender') && searchParams.get('category') ? <ModalSubCat/> : null
                }
            </div>
        );
    }
;

export default SubCategory;