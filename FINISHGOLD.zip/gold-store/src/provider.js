import React, {useState, useContext, createContext} from 'react';
import ring from "./Images/ring.png"
import cep from "./Images/cep.png"
import product from "./Images/product.png"
import mainRing from "./Images/mainRing.png"

const ToDoContext = createContext({})


const ToDo = ({children}) => {
    const [value, setValue] = useState("")
    const [search, setSearch] = useState("")
    const [subval, setSubval] = useState("")
    const [showBtn, setShowBtn] = useState(true)
    const [showCat, setShowCat] = useState(null)

    const [item, setItem] = useState([
        {
        id: Math.random(),
        img: ring,
        name: "ring",
        spouse: "woman"
    },
    //
        {
            id: Math.random(),
            img: cep,
            name: "Цепь",
            spouse: "man"
        },
    ])
     // const [item, setItem] = useState(JSON.parse(localStorage.getItem('item')))

    const [cat, setCat] = useState([
        {id: Math.random(), name: "ring r", cat: "ring"},
        {id: Math.random(), name: "ring for married", cat: "ring"},
        {id: Math.random(), name: "Цепь r", cat: "Цепь"},
        {id: Math.random(), name: "Цепь  for married", cat: "Цепь"}
    ])


    // const [cat, setCat] = useState(JSON.parse(localStorage.getItem('cat')))

    const [open, setOpen] = React.useState(false);
    const handleOpen = () => setOpen(true);
    const handleClose = () => setOpen(false);
    const style1 = {
        position: 'absolute',
        top: '50%',
        left: '50%',
        transform: 'translate(-50%, -50%)',
        width: "300px",
        height: "max-content",
        backgroundColor: '#FFFFFF',
        borderRadius: "5px",
        boxShadow: 24,
        p: 4,
    };
    // 2 modal
    const [open2, setOpen2] = React.useState(false);
    const handleOpen2 = () => setOpen2(true);
    const handleClose2 = () => setOpen2(false);
    const style2 = {
        position: 'absolute',
        top: '50%',
        left: '50%',
        transform: 'translate(-50%, -50%)',
        width: "345px",
        color: "#2E2E2E",
        height: "max-content",
        backgroundColor: '#FFFFFF',
        borderRadius: "5px",
        boxShadow: 24,
        p: 4,
    };
    // 3 modal

    const [open3, setOpen3] = React.useState(false);
    const handleOpen3 = () => {
        setOpen3(true)
        setSearch("")
    };
    const handleClose3 = () => setOpen3(false);
    // 4 modal


    const [open4, setOpen4] = React.useState(false);
    const handleOpen4 = () => setOpen4(true);
    const handleClose4 = () => setOpen4(false);
    const style4 = {
        position: 'absolute',
        top: '50%',
        left: '50%',
        transform: 'translate(-50%, -50%)',
        width: "345px",
        color: "#2E2E2E",
        height: "max-content",
        backgroundColor: '#FFFFFF',
        borderRadius: "5px",
        boxShadow: 24,
        p: 4,
    };
    const [uploadSuccess, setUploadSuccess] = useState(false);
    const getUploadParams = () => {
        return {url: "https://httpbin.org/post"};
    };
    const handleChangeStatus = ({meta}, status) => {
        setUploadSuccess(false);
        let img = []
        img.push(meta.name)
    };


    const [images, setImages] = useState([])
    const [imgURLs, setImgURLs] = useState([])


    function onImageChange(e) {
        setImages([...e.target.files])
    }

    const [images2, setImages2] = useState([])
    const [imgURLs2, setImgURLs2] = useState([])

    function onImageChange2(e) {
        setImages2([...e.target.files])
    }



    const [gender, setGender] = useState("woman")
    const [gender2, setGender2] = useState("woman")
    const [active, setActive] = useState(false)

    const [names, setNames] = useState(null)

    const [products, setProducts] = useState([
        {
            name: "man",
            id: Math.random(),
            img: product,
            spouse: gender,
            price: 2400,
            category: "Цепь  for married"
        },
        {
            name: "women",
            id: Math.random(),
            img: mainRing,
            spouse: gender,
            price: 3500,
            category: "ring for married"
        },
        {
            name: "man",
            id: Math.random(),
            img: product,
            spouse: gender,
            price: 10500,
            category: "Цепь r"
        },
        {
            name: "woman",
            id: Math.random(),
            img: mainRing,
            spouse: gender,
            price: 6500,
            category: "ring r"
        },

    ])

   // const [products, setProducts] = useState(JSON.parse(localStorage.getItem('products')))


    let defaultDate = new Date()
    defaultDate.setDate(defaultDate.getDate() + 3)


    const [date, setDate] = useState(defaultDate)
    const [date2, setDate2] = useState(defaultDate)
    const onSetDate = (event) => {
        setDate(new Date(event.target.value))
    }
    const onSetDate2 = (event) => {
        setDate2(new Date(event.target.value))
    }


    const parsePrice = x => parseFloat(x) || 0
    const sortedProds = products.slice().sort((a, b) => parsePrice(a.price) - parsePrice(b.price))
    const [rangeVal, setRangeVal] = useState([0, sortedProds[sortedProds.length-1].price]);

    const handleChangeRange = (event, newValue) => {
        setRangeVal(newValue);
    };


    const [prod, setProd] = useState(null)
    const [sub, setSub] = useState(null)
    const [val1, setVal1] = useState("")
    const [val2, setVal2] = useState("")

    const [choosen,setChoosen] = useState()
    const [choosen1,setChoosen1] = useState()



    return (
        <ToDoContext.Provider value={{
            value,
            choosen,
            setChoosen,
            choosen1,
            setChoosen1,
            setValue,
            item,
            setItem,
            style1,
            open,
            setOpen,
            handleOpen,
            handleClose,
            uploadSuccess,
            setUploadSuccess,
            getUploadParams,
            handleChangeStatus,
            cat,
            setCat,
            addCategory,
            images,
            setImages,
            imgURLs,
            setImgURLs,
            search,
            setSearch,
            onImageChange,
            onImageChange2,
            showBtn,
            setShowBtn,
            gender,
            setGender,
            active,
            setActive,
            open2,
            setOpen2,
            handleOpen2,
            handleClose2,
            open4,
            setOpen4,
            handleOpen4,
            handleClose4,
            style2,
            subval,
            setSubval,
            gender2,
            setGender2,
            showCat,
            setShowCat,
            names,
            setNames,
            products,
            setProducts,
            open3,
            setOpen3,
            handleOpen3,
            handleClose3,
            style4,
            date,
            setDate,
            onSetDate,
            date2,
            setDate2,
            onSetDate2,
            rangeVal,
            setRangeVal,
            handleChangeRange,
            prod,
            setProd,
            sub,
            setSub,
            images2,
            setImages2,
            imgURLs2,
            setImgURLs2,
            val1,
            setVal1,
            val2,
            setVal2,
            sortedProds
        }}>
            {children}
        </ToDoContext.Provider>
    )
}
const addCategory = () => {
}
const useToDo = () => {
    return useContext(ToDoContext)

}
export {useToDo, ToDo}