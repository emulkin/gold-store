import './App.css';
import "bootstrap/dist/css/bootstrap.css"
import React from "react";
import Header from "./components/Header/header";
import Category from "./components/categories/category";
import Filter from "./components/filter/filter";
import SubCategory from "./components/subCategories/subCategory";
import Products from "./components/Products/products";

function App() {


    return (
        <div className="App">
            <Header/>
            <Category/>
            <SubCategory/>
            {/*<Routes>*/}
            {/*    {*/}
            {/*        subArray.map(({id,name,element,path})=>{*/}
            {/*            return(*/}
            {/*                <Route key={id} element={element} path={path}/>*/}
            {/*            )*/}
            {/*        })*/}
            {/*    }*/}
            {/*</Routes>*/}
            <Products/>
            <Filter/>
        </div>
    );
}

export default App;
